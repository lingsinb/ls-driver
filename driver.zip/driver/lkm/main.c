/* main.c — LKM 形态驱动 (需 insmod / Magisk 模块自动加载)
 *
 * 暴露能力: 进程查询 / TTBR0 获取 / 模块基址 / 物理内存读写 / 虚拟内存读写 / 自隐藏
 * 反检测:
 *   - 设备名伪装成 ksud 诊断节点
 *   - 命令字自定义, 不使用 _IOWR 标准编码
 *   - 每会话随机密钥流加扰 payload
 *   - 加载后立即摘链 (可配置)
 */
#include <linux/module.h>
#include <linux/kernel.h>
#include <linux/fs.h>
#include <linux/cdev.h>
#include <linux/device.h>
#include <linux/uaccess.h>
#include <linux/slab.h>
#include <linux/sched.h>
#include <linux/mm.h>
#include <linux/pid.h>
#include <linux/mm_types.h>
#include <linux/io.h>
#include <linux/highmem.h>
#include <linux/version.h>
#include <linux/random.h>
#include <linux/string.h>
#include <linux/mmap_lock.h>
#include <asm/memory.h>
#include <asm/pgtable.h>

#include "../common/proto.h"
#include "../common/crypto.h"
#include "../common/ptwalk.h"
#include "../common/util.h"

#define PK_DEV_COUNT 1

static int pk_major;
static struct class *pk_class;
static struct cdev pk_cdev;
static dev_t pk_devno;

static struct pk_crypt g_crypt;
static bool g_crypted;
static u32 g_last_seq;

/* 物理内存读写: 内核直映射窗口内直接访问 */
static int pk_rd_phys(__u64 pa, void *buf, __u32 len)
{
    if (!pfn_valid(PHYS_PFN(pa)) || !pfn_valid(PHYS_PFN(pa + len - 1)))
        return -1;
    memcpy(buf, __va(pa), len);
    return 0;
}

static int pk_wr_phys(__u64 pa, const void *buf, __u32 len)
{
    if (!pfn_valid(PHYS_PFN(pa)) || !pfn_valid(PHYS_PFN(pa + len - 1)))
        return -1;
    memcpy(__va(pa), buf, len);
    return 0;
}

static __u64 pk_get_ttbr0(struct task_struct *task)
{
    struct mm_struct *mm;
    __u64 pgd_va, pgd_pa;

    if (!task)
        return 0;

    mm = task->mm;
    if (!mm)
        mm = task->active_mm;
    if (!mm || !mm->pgd)
        return 0;

    pgd_va = (__u64)mm->pgd;
    /* 内核直映射区 -> 物理; 高版本内核用 __pa 语义一致 */
    pgd_pa = __pa(pgd_va);
    return pgd_pa;
}

static int pk_get_pid_by_name(const char *name, __u32 *out)
{
    struct task_struct *t;
    char comm[TASK_COMM_LEN];
    int found = -1;

    rcu_read_lock();
    for_each_process(t) {
        memset(comm, 0, sizeof(comm));
        memcpy(comm, t->comm, TASK_COMM_LEN - 1);
        if (strstr(comm, name)) {
            *out = t->pid;
            found = 0;
            break;
        }
    }
    rcu_read_unlock();
    return found;
}

/* 取内核模块(so)基址: 遍历目标进程 vma, 匹配 pathname 结尾 */
static __u64 pk_get_module_base(__u32 pid, const char *soname)
{
    struct task_struct *t;
    struct mm_struct *mm;
    struct vm_area_struct *vma;
    __u64 base = 0;

    t = pk_task_by_pid(pid);
    if (!t)
        return 0;

    mm = t->mm;
    if (!mm) {
        put_task_struct(t);
        return 0;
    }

    mmap_read_lock(mm);
#if LINUX_VERSION_CODE >= KERNEL_VERSION(6, 1, 0)
    {
        VMA_ITERATOR(vmi, mm, 0);
        for_each_vma(vmi, vma) {
            struct file *f = vma->vm_file;
            if (!f)
                continue;
            {
                const char *path = (const char *)f->f_path.dentry->d_name.name;
                if (path && strstr(path, soname)) {
                    if (!base || vma->vm_start < base)
                        base = vma->vm_start;
                }
            }
        }
    }
#else
    for (vma = mm->mmap; vma; vma = vma->vm_next) {
        struct file *f = vma->vm_file;
        if (!f)
            continue;
        {
            const char *path = (const char *)f->f_path.dentry->d_name.name;
            if (path && strstr(path, soname)) {
                if (!base || vma->vm_start < base)
                    base = vma->vm_start;
            }
        }
    }
#endif
    mmap_read_unlock(mm);
    put_task_struct(t);
    return base;
}

static long pk_do_ioctl(struct file *f, unsigned int cmd, unsigned long arg)
{
    struct pk_req req;
    struct pk_rsp rsp;
    struct pk_crypt c;
    struct pk_ptcfg cfg;
    __u32 op = cmd & 0xffff;
    int ret = 0;

    (void)f;

    if ((cmd & 0xffff0000u) != PK_MAGIC)
        return -EINVAL;

    /* --- 握手不加密, 单结构双向 --- */
    if (op == PK_OP_HANDSHAKE) {
        struct pk_handshake hs;
        __u8 client[PK_NONCE_LEN];
        __u8 sn[PK_NONCE_LEN];
        __u64 seed;

        if (copy_from_user(&hs, (void __user *)arg, sizeof(hs)))
            return -EFAULT;

        memcpy(client, hs.server_nonce, PK_NONCE_LEN);
        get_random_bytes(sn, PK_NONCE_LEN);
        memcpy(hs.server_nonce, sn, PK_NONCE_LEN);
        get_random_bytes(hs.session_id, PK_SESSION_LEN);
        hs.status = 0;

        seed = pk_seed_from_nonce(client, sn, PK_NONCE_LEN);
        pk_crypt_init(&g_crypt, seed);
        g_crypted = true;
        g_last_seq = 0;

        if (copy_to_user((void __user *)arg, &hs, sizeof(hs)))
            return -EFAULT;
        return 0;
    }

    if (copy_from_user(&req, (void __user *)arg, sizeof(req)))
        return -EFAULT;

    memset(&rsp, 0, sizeof(rsp));

    /* --- 其余命令必须已握手 + seq 递增 --- */
    if (!g_crypted)
        return -EACCES;

    if (req.h.seq <= g_last_seq)
        return -EINVAL;

    g_last_seq = req.h.seq;

    /* 只有写类命令的数据区是加密的; 读类不回传密文, 保持密钥流同步 */
    if (op == PK_OP_WRITE_PHYS || op == PK_OP_WRITE_VIRT) {
        c = g_crypt;
        pk_crypt_apply(&c, req.data, PK_MAX_XFER);
        g_crypt = c;
        if (req.h.crc != pk_crc32(req.data, req.h.len))
            return -EBADMSG;
    }

    /* 修正: len 存在 hdr 里, 复用 pad 字段 */
    switch (op) {
    case PK_OP_PING:
        rsp.status = 0;
        break;

    case PK_OP_GET_PID: {
        __u32 pid = 0;
        char name[33];
        memcpy(name, req.u.by_name.name, 32);
        name[32] = 0;
        if (pk_get_pid_by_name(name, &pid) == 0) {
            rsp.value = pid;
            rsp.status = 0;
        } else {
            rsp.status = 1;
        }
        break;
    }

    case PK_OP_GET_CR3: {
        struct task_struct *t = pk_task_by_pid(req.u.by_pid.pid);
        if (!t) { rsp.status = 2; break; }
        rsp.value = pk_get_ttbr0(t);
        put_task_struct(t);
        rsp.status = rsp.value ? 0 : 3;
        break;
    }

    case PK_OP_MOD_BASE: {
        char name[33];
        memcpy(name, req.u.by_name.name, 32);
        name[32] = 0;
        rsp.value = pk_get_module_base(req.u.by_pid.pid, name);
        rsp.status = rsp.value ? 0 : 4;
        break;
    }

    case PK_OP_READ_PHYS:
        if (req.u.xfer.size > PK_MAX_XFER) { rsp.status = 5; break; }
        if (pk_rd_phys(req.u.xfer.addr, rsp.data, req.u.xfer.size) == 0) {
            rsp.len = req.u.xfer.size;
            rsp.status = 0;
        } else {
            rsp.status = 6;
        }
        break;

    case PK_OP_WRITE_PHYS:
        if (req.u.xfer.size > PK_MAX_XFER) { rsp.status = 5; break; }
        if (pk_wr_phys(req.u.xfer.addr, req.data, req.u.xfer.size) == 0)
            rsp.status = 0;
        else
            rsp.status = 6;
        break;

    case PK_OP_READ_VIRT:
    case PK_OP_WRITE_VIRT: {
        struct task_struct *t = pk_task_by_pid(req.u.xfer.pid);
        if (!t) { rsp.status = 2; break; }
        memset(&cfg, 0, sizeof(cfg));
        cfg.ttbr0     = pk_get_ttbr0(t);
        cfg.page_shift = PAGE_SHIFT;
        cfg.va_bits   = VA_BITS;
        put_task_struct(t);

        if (req.u.xfer.size > PK_MAX_XFER) { rsp.status = 5; break; }

        if (op == PK_OP_READ_VIRT) {
            if (pk_read_virt(&cfg, req.u.xfer.addr, rsp.data,
                             req.u.xfer.size, pk_rd_phys) == 0) {
                rsp.len = req.u.xfer.size;
                rsp.status = 0;
            } else {
                rsp.status = 7;
            }
        } else {
            if (pk_write_virt(&cfg, req.u.xfer.addr, req.data,
                              req.u.xfer.size, pk_wr_phys) == 0)
                rsp.status = 0;
            else
                rsp.status = 7;
        }
        break;
    }

    case PK_OP_HIDE_SELF:
        pk_hide_self(KBUILD_MODNAME);
        rsp.status = 0;
        break;

    default:
        return -ENOTTY;
    }

    ret = 0;
    if (copy_to_user((void __user *)arg, &rsp, sizeof(rsp)))
        return -EFAULT;
    return ret;
}

static long pk_ioctl(struct file *f, unsigned int cmd, unsigned long arg)
{
    long r;
    /* 简单防扫描: 非法命令不返回明显错误码 */
    r = pk_do_ioctl(f, cmd, arg);
    if (r == -ENOTTY)
        r = -EINVAL;
    return r;
}

static const struct file_operations pk_fops = {
    .owner          = THIS_MODULE,
    .unlocked_ioctl = pk_ioctl,
    .compat_ioctl   = pk_ioctl,
};

static int __init pk_init(void)
{
    int ret;

    ret = alloc_chrdev_region(&pk_devno, 0, PK_DEV_COUNT, PK_DEV_NAME);
    if (ret < 0)
        return ret;

    pk_major = MAJOR(pk_devno);
    cdev_init(&pk_cdev, &pk_fops);
    pk_cdev.owner = THIS_MODULE;
    ret = cdev_add(&pk_cdev, pk_devno, PK_DEV_COUNT);
    if (ret < 0)
        goto err_cdev;

#if LINUX_VERSION_CODE >= KERNEL_VERSION(6, 4, 0)
    pk_class = class_create(PK_DEV_NAME);
#else
    pk_class = class_create(THIS_MODULE, PK_DEV_NAME);
#endif
    if (IS_ERR(pk_class)) {
        ret = PTR_ERR(pk_class);
        goto err_class;
    }

    if (IS_ERR(device_create(pk_class, NULL, pk_devno, NULL, PK_DEV_NAME))) {
        ret = -ENODEV;
        goto err_dev;
    }

    pr_info("pk: loaded, major=%d\n", pk_major);
    return 0;

err_dev:
    class_destroy(pk_class);
err_class:
    cdev_del(&pk_cdev);
err_cdev:
    unregister_chrdev_region(pk_devno, PK_DEV_COUNT);
    return ret;
}

static void __exit pk_exit(void)
{
    device_destroy(pk_class, pk_devno);
    class_destroy(pk_class);
    cdev_del(&pk_cdev);
    unregister_chrdev_region(pk_devno, PK_DEV_COUNT);
}

module_init(pk_init);
module_exit(pk_exit);

MODULE_LICENSE("GPL");
MODULE_DESCRIPTION("md");
MODULE_AUTHOR("");
