/* crypto.c */
#include "crypto.h"

void pk_crypt_init(struct pk_crypt *c, __u64 seed)
{
    /* splitmix64 派生两个 64bit 状态 */
    __u64 x = seed ^ 0x9E3779B97F4A7C15ULL;
    __u64 z;
    int i;

    for (i = 0; i < 2; i++) {
        x += 0x9E3779B97F4A7C15ULL;
        z = x;
        z = (z ^ (z >> 30)) * 0xBF58476D1CE4E5B9ULL;
        z = (z ^ (z >> 27)) * 0x94D049BB133111EBULL;
        c->s[i] = z ^ (z >> 31);
    }
    c->idx = 0;
}

static __u64 pk_next(struct pk_crypt *c)
{
    /* xorshift128+ */
    __u64 x = c->s[0];
    const __u64 y = c->s[1];
    c->s[0] = y;
    x ^= x << 23;
    c->s[1] = x ^ y ^ (x >> 17) ^ (y >> 26);
    return c->s[1] + y;
}

void pk_crypt_apply(struct pk_crypt *c, void *buf, __u32 len)
{
    __u8 *p = (__u8 *)buf;
    __u32 i = 0;

    while (i < len) {
        __u64 k = pk_next(c);
        int n = (len - i) < 8 ? (int)(len - i) : 8;
        int j;
        for (j = 0; j < n; j++)
            p[i + j] ^= (__u8)(k >> (j * 8));
        i += n;
        /* 每 256 字节混入一次长度扰动, 防止已知明文攻击推密钥流 */
        if ((i & 0xff) == 0)
            c->s[0] ^= (__u64)len * 0x100000001B3ULL;
    }
}

__u32 pk_crc32(const void *buf, __u32 len)
{
    const __u8 *p = (const __u8 *)buf;
    __u32 crc = 0xFFFFFFFFu;
    __u32 i, j;

    for (i = 0; i < len; i++) {
        crc ^= p[i];
        for (j = 0; j < 8; j++)
            crc = (crc >> 1) ^ (0xEDB88320u & (~(crc & 1) + 1));
    }
    return ~crc;
}

__u64 pk_seed_from_nonce(const __u8 *client, const __u8 *server, __u32 len)
{
    __u64 seed = 0xA5A5DEADBEEF1234ULL;
    __u32 i;

    for (i = 0; i < len; i++) {
        seed ^= (__u64)client[i] << ((i % 8) * 8);
        seed = (seed << 7) | (seed >> 57);
        seed ^= (__u64)server[i] * 0xFF51AFD7ED558CCDULL;
        seed ^= seed >> 29;
    }
    return seed;
}
