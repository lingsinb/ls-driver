/* proto.h — 驱动 <-> 用户态 通信协议
 * 设计要点:
 *   1) 不走标准 _IOWR 编码, 用自造 32bit 命令字, 规避 ACE 对 dispatch 层常见 ioctl 魔数的模式匹配
 *   2) 每个请求带 seq + 会话密钥流加密, 重放/伪造包直接丢弃
 *   3) 一次 ioctl 只做一件事, payload 定长, 不做变长结构, 减少拷贝痕迹
 */
#ifndef _PK_PROTO_H
#define _PK_PROTO_H

#include <linux/types.h>

#define PK_DEV_NAME     "ksud_diag"     /* 伪装成 KernelSU 诊断节点 */
#define PK_MAGIC        0x5A4B0000u

/* 命令字: 高16位魔数, 低16位 opcode */
enum pk_op {
    PK_OP_HANDSHAKE   = 0x0001,  /* 交换会话密钥 */
    PK_OP_GET_PID     = 0x0002,  /* 进程名 -> pid */
    PK_OP_GET_CR3     = 0x0003,  /* pid -> ttbr0 物理基址 */
    PK_OP_MOD_BASE    = 0x0004,  /* pid + 模块名 -> 模块基址 */
    PK_OP_READ_PHYS   = 0x0005,  /* 物理地址读 */
    PK_OP_WRITE_PHYS  = 0x0006,  /* 物理地址写 */
    PK_OP_READ_VIRT   = 0x0007,  /* 虚拟地址读 (内部走页表) */
    PK_OP_WRITE_VIRT  = 0x0008,  /* 虚拟地址写 */
    PK_OP_HIDE_SELF   = 0x0009,  /* 摘链/隐藏 */
    PK_OP_PING        = 0x000a,
};

#define PK_IOCTL_CMD(op) (PK_MAGIC | ((op) & 0xffff))

/* 每条命令最大传输量, 超过由用户态分片 */
#define PK_MAX_XFER     0x400       /* 1KB */

#define PK_SESSION_LEN  16
#define PK_NONCE_LEN    8

struct pk_hdr {
    __u32 cmd;              /* 明文命令字 */
    __u32 seq;              /* 单调递增, 驱动侧校验 */
    __u64 nonce;            /* 本次会话派生, 防重放 */
    __u32 crc;              /* payload 明文 crc32, 加密前计算 */
    __u32 len;              /* data 区有效长度 */
};

struct pk_req {
    struct pk_hdr h;
    union {
        struct {
            char name[32];
        } by_name;          /* GET_PID / MOD_BASE */
        struct {
            __u32 pid;
        } by_pid;
        struct {
            __u32 pid;
            __u64 addr;     /* 物理或虚拟地址 */
            __u32 size;
        } xfer;
        __u8 raw[256];
    } u;
    __u8 data[PK_MAX_XFER]; /* 加扰后的数据区 */
};

struct pk_rsp {
    __u32 status;           /* 0 = ok */
    __u32 len;
    __u64 value;            /* pid / cr3 / base */
    __u8  data[PK_MAX_XFER];
};

/* 握手: 客户端把 client_nonce 填在 server_nonce 位置下发, 驱动原地回写。
 * 单结构双向, 避免长度不一致导致的越界。 */
struct pk_handshake {
    __u8 server_nonce[PK_NONCE_LEN];   /* in: client_nonce / out: server_nonce */
    __u8 session_id[PK_SESSION_LEN];
    __u32 status;
};

#endif /* _PK_PROTO_H */
