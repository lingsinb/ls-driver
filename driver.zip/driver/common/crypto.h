/* crypto.h — 轻量会话加密 (XOR 流 + 混合常量, 足够对抗内存扫描/简单流量特征, 不追求密码学强度) */
#ifndef _PK_CRYPTO_H
#define _PK_CRYPTO_H

#include <linux/types.h>

struct pk_crypt {
    __u64 s[2];
    __u32 idx;
};

void pk_crypt_init(struct pk_crypt *c, __u64 seed);
void pk_crypt_apply(struct pk_crypt *c, void *buf, __u32 len); /* 加解密同一函数 */
__u32 pk_crc32(const void *buf, __u32 len);
__u64 pk_seed_from_nonce(const __u8 *client, const __u8 *server, __u32 len);

#endif
