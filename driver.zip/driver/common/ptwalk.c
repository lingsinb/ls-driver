/* ptwalk.c */
#include <linux/kernel.h>
#include <linux/string.h>
#include <asm/memory.h>
#include "ptwalk.h"

#define PK_PTE_VALID      (1ULL << 0)
#define PK_PTE_TABLE      (1ULL << 1)
#define PK_PTE_PAGE       (1ULL << 1)
#define PK_PTE_AF         (1ULL << 10)
#define PK_PTE_ADDR_MASK  0x0000FFFFFFFFF000ULL
#define PK_TTBR_BADDR_MASK 0x0000FFFFFFFFF000ULL

static inline __u64 pk_rd64(__u64 phys)
{
    return *(volatile __u64 *)__va(phys);
}

int pk_walk(struct pk_ptcfg *cfg, __u64 vaddr, __u64 *paddr)
{
    __u32 shift = cfg->page_shift;
    __u32 bits = shift - 3;
    __u32 levels, start, level;
    __u64 table, desc, idx;

    if (!cfg->ttbr0 || !cfg->page_shift || !cfg->va_bits)
        return -1;
    if (vaddr >> cfg->va_bits)
        return -1;

    /* 需要的级数 (向上取整) */
    levels = (cfg->va_bits - shift + bits - 1) / bits;
    if (levels > 4 || levels < 2)
        return -1;
    start = 4 - levels;

    table = cfg->ttbr0 & PK_TTBR_BADDR_MASK;

    for (level = start; level < 4; level++) {
        __u32 lshift = shift + bits * (3 - level);

        idx = (vaddr >> lshift) & ((1ULL << bits) - 1);
        desc = pk_rd64(table + idx * 8);

        if (!(desc & PK_PTE_VALID))
            return -1;

        if (level == 3) {
            /* 最后一级: 必须是 page descriptor (bit1 == 1) */
            if (!(desc & PK_PTE_PAGE))
                return -1;
            *paddr = (desc & PK_PTE_ADDR_MASK) |
                     (vaddr & ((1ULL << shift) - 1));
            return 0;
        }

        if (desc & PK_PTE_TABLE) {
            /* table descriptor -> 下一级 */
            table = desc & PK_PTE_ADDR_MASK;
            continue;
        }

        /* block descriptor: 大页映射, 直接算偏移 */
        {
            __u64 base = desc & PK_PTE_ADDR_MASK & ~((1ULL << lshift) - 1);
            *paddr = base | (vaddr & ((1ULL << lshift) - 1));
            return 0;
        }
    }
    return -1;
}

int pk_read_virt(struct pk_ptcfg *cfg, __u64 vaddr, void *buf, __u32 len,
                 int (*rd_phys)(__u64 pa, void *buf, __u32 len))
{
    __u8 *out = (__u8 *)buf;
    __u32 done = 0;
    __u32 page = 1u << cfg->page_shift;

    while (done < len) {
        __u64 pa;
        __u32 chunk;

        if (pk_walk(cfg, vaddr + done, &pa) < 0)
            return -1;

        chunk = page - (__u32)(pa & (page - 1));
        if (chunk > len - done)
            chunk = len - done;

        if (rd_phys(pa, out + done, chunk) < 0)
            return -1;

        done += chunk;
    }
    return 0;
}

int pk_write_virt(struct pk_ptcfg *cfg, __u64 vaddr, const void *buf, __u32 len,
                  int (*wr_phys)(__u64 pa, const void *buf, __u32 len))
{
    const __u8 *in = (const __u8 *)buf;
    __u32 done = 0;
    __u32 page = 1u << cfg->page_shift;

    while (done < len) {
        __u64 pa;
        __u32 chunk;

        if (pk_walk(cfg, vaddr + done, &pa) < 0)
            return -1;

        chunk = page - (__u32)(pa & (page - 1));
        if (chunk > len - done)
            chunk = len - done;

        if (wr_phys(pa, in + done, chunk) < 0)
            return -1;

        done += chunk;
    }
    return 0;
}
