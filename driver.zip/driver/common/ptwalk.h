/* ptwalk.h — ARM64 页表遍历: 虚拟地址 -> 物理地址, 走目标进程的 TTBR0
 * 支持 4K / 16K / 64K 页粒度, 覆盖内核 5.4 ~ 6.6 全部主流 Android 分支
 */
#ifndef _PK_PTWALK_H
#define _PK_PTWALK_H

#include <linux/types.h>
#include <linux/mm_types.h>

struct pk_ptcfg {
    __u64 ttbr0;        /* 进程页表物理基址 */
    __u32 page_shift;   /* 12 / 14 / 16 */
    __u32 va_bits;      /* 39 / 48 / 52 */
};

/* 返回值: 0 成功; <0 失败 */
int pk_walk(struct pk_ptcfg *cfg, __u64 vaddr, __u64 *paddr);
int pk_read_virt(struct pk_ptcfg *cfg, __u64 vaddr, void *buf, __u32 len,
                 int (*rd_phys)(__u64 pa, void *buf, __u32 len));
int pk_write_virt(struct pk_ptcfg *cfg, __u64 vaddr, const void *buf, __u32 len,
                  int (*wr_phys)(__u64 pa, const void *buf, __u32 len));

#endif
